import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-home',
    templateUrl: './home.component.html',
    styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

    today = new Date();
    discount = Math.floor(Math.random() * 11);
    imageWidth = 200;
    applyColors = false;
    isWinter: boolean;
    items = ["bread", "pizza", "shirt"];
    headStyle = { "color": this.discount <= 5 ? "black" : "red", "fontStyle": this.discount < 8 ? "normal" : "italic" };

    constructor() {

        let date = new Date();
        let month = date.getMonth();
        this.isWinter = month == 12 || month == 1 || month == 2;
    }

    ngOnInit(): void {
    }

    increaseWidth() {
        this.imageWidth += 10;
    }
    decreaseWidth() {
        this.imageWidth -= 10;
    }
    resetWidth() {
        this.imageWidth = 200;
    }

}
