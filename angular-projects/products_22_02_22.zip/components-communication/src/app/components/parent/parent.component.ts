import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-parent',
  templateUrl: './parent.component.html',
  styleUrls: ['./parent.component.css']
})
export class ParentComponent {

   
    // mthod for string event
    f1(theEvent:string){
        alert(theEvent)
    }
    // mthod for object event
    f2(theEvent:{id: number, name:string}){
        alert("id: " + theEvent.id + ", name: " + theEvent.name);
    }
  

}
