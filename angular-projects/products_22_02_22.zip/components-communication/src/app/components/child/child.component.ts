import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
    selector: 'app-child',
    templateUrl: './child.component.html',
    styleUrls: ['./child.component.css']
})
export class ChildComponent {

    point:{x:number, y:number} = {x:25, y:32};

    @Input()
    public name: string = "";


    @Output()
    // event of type string
    //public sendNameEvent:EventEmitter<string> = new EventEmitter<string>();
    // event of type object
    public sendNameEvent = new EventEmitter<{id: number, name:string}>();

    
    public fireNameEvent(){
        // emit the string event
        // this.sendNameEvent.emit("child name is " + this.name);
        // emit the object event
        this.sendNameEvent.emit({id:101, name:this.name});
    }
    
    @Output()
    public sendPointEvent = new EventEmitter<{x: number, y:number}>();

    public firePointEvent(){
        this.sendPointEvent.emit(this.point);
    }

   


}
