import { Injectable } from '@angular/core';
import { Product } from '../models/product.model';

@Injectable({
    providedIn: 'root'
})
export class ProductsService {

    constructor() { }

    public getAllProducts(): Product[] {
        // create an array of Product elements
        let arr: Product[] = [];
        // add products to the array
        arr.push(new Product(1, "Bread", 5.80, 200));
        arr.push(new Product(2, "Milk", 12.90, 50));
        arr.push(new Product(3, "Honey", 25.80, 10));
        arr.push(new Product(4, "Apple", 14, 400));
        arr.push(new Product(5, "Tomato", 3.60, 125));
        arr.push(new Product(6, "TV", 7600, 4));
        // return the array
        return arr;
    }

    public x() {
        // console.log("hello from service");
        alert("hello from service");
    }
}
