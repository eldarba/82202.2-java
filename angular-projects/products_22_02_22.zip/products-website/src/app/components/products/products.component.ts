import { Component, OnInit } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { Product } from 'src/app/models/product.model';
import { ProductsService } from 'src/app/services/products.service';

@Component({
    selector: 'app-products',
    templateUrl: './products.component.html',
    styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {

    public products! :Product[];

    // inject services (DI - Dependency Injection) using the CTOR
    constructor(private titleService: Title, private productService:ProductsService) { }

    ngOnInit(): void {
        this.titleService.setTitle("Products");
        this.products = this.productService.getAllProducts();
    }

    public activateService(){
        this.productService.x();
    }

}
