import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
 

  myCondition = true;

  arr = ["red", "green", "blue"];

  sentence = "";
  sentences = [
      "Hello class.", 
      "today we are going to see directives.", 
      "this is ngFor."
    ];

  changeCondition(){
      this.myCondition = !this.myCondition;
  }

  divColor = "red";
  divBg = "yellow";

}
