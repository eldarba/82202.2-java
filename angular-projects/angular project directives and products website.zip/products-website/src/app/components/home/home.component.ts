import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-home',
    templateUrl: './home.component.html',
    styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

    today = new Date();
    discount = 2;
    imageWidth = 200;

    constructor() { }

    ngOnInit(): void {
    }

    increaseWidth() {
        this.imageWidth += 10;
    }
    decreaseWidth() {
        this.imageWidth -= 10;
    }
    resetWidth() {
        this.imageWidth = 200;
    }

}
