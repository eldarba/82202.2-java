import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { observable, Observable, Subscriber } from 'rxjs';
import { Product } from '../models/product.model';

@Injectable({
    providedIn: 'root'
})
export class ProductsService {

    constructor(private httpClient: HttpClient) { }

    public getOneProduct(productId: number): Observable<Product>{
        // get the token from the browser's session storage
        let token: string | null = sessionStorage.getItem('token');
        // set token so it is not null
        token = token ? token : "";
        let url = "http://localhost:8080/api/product/" + productId;
        // put the token in the http headers
        let theHeaders = new HttpHeaders().set("token", token);
        let options = {headers: theHeaders};
        return this.httpClient.get<Product>(url, options);

    }

    public getAllProductsHttp(): Observable<Product[]> {
        // get the token from the browser's session storage
        let token: string | null = sessionStorage.getItem('token');
        // set token so it is not null
        token = token ? token : "";
        let url = "http://localhost:8080/api/product";
        // put the token in the http headers
        let theHeaders = new HttpHeaders().set("token", token);
        let options = {headers: theHeaders};
        return this.httpClient.get<Product[]>(url, options);
    }

    // ===========================================================================

    public getAllProducts(): Product[] {
        // create an array of Product elements
        let arr: Product[] = [];
        // add products to the array
        arr.push(new Product(1, "Bread", 5.80, 200));
        arr.push(new Product(2, "Milk", 12.90, 50));
        arr.push(new Product(3, "Honey", 25.80, 10));
        arr.push(new Product(3, "Honey", 25.80, 10));
        arr.push(new Product(3, "Honey", 25.80, 10));
        arr.push(new Product(3, "Honey", 25.80, 10));
        arr.push(new Product(3, "Honey", 25.80, 10));
        arr.push(new Product(3, "Honey", 25.80, 10));
        // return the array
        return arr;
    }

    // asynchronius method = returns Observable<Product[]>
    public getAllProductsAsynch(): Observable<Product[]> {

        // 1. create a subsribe argument - a function to tell the observable what to do
        let subscribeFuction = (subscriber: Subscriber<Product[]>) => {
            let arr: Product[] = [];
            setTimeout(() => {
                if (Math.random() < 0) {
                    subscriber.error("get all products failed");
                    return;
                }
                arr.push(new Product(1, "Bread", 5.80, 200));
                arr.push(new Product(2, "Milk", 12.90, 50));
                arr.push(new Product(3, "Honey", 25.80, 10));

                subscriber.next(arr); // notify subscriber with new data

            }, 3000);

            setTimeout(() => {
                arr.push(new Product(1, "Bread", 5.80, 200));
                arr.push(new Product(2, "Milk", 12.90, 50));
                arr.push(new Product(3, "Honey", 25.80, 10));

                subscriber.next(arr); // notify subscriber with new data

                subscriber.complete();

            }, 5000);
        };

        // 2. create an observable object
        let observable: Observable<Product[]> = new Observable(subscribeFuction);
        // 3. return the observable
        return observable;
    }

    public x() {
        // console.log("hello from service");
        alert("hello from service");
    }
}
