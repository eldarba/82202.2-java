import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Product } from 'src/app/models/product.model';
import { ProductsService } from 'src/app/services/products.service';

@Component({
    selector: 'app-product-details',
    templateUrl: './product-details.component.html',
    styleUrls: ['./product-details.component.css']
})
export class ProductDetailsComponent implements OnInit {

    public product!: Product;

    constructor(private activatedRout:ActivatedRoute, private productService:ProductsService) { }

    ngOnInit(): void {
        let productId = this.activatedRout.snapshot.params['id'];
        let subscription = this.productService.getOneProduct(productId).subscribe({
            next: (productFromServer)=>{
                this.product = productFromServer;
            },
            error:(e)=>{
                alert(e.error.message)
            },
            complete:()=>{
                subscription.unsubscribe();
            }
        });
       

    }

}
