import { Component, OnInit } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { Observable, Observer, Subscription } from 'rxjs';
import { Product } from 'src/app/models/product.model';
import { ProductsService } from 'src/app/services/products.service';

@Component({
    selector: 'app-products',
    templateUrl: './products.component.html',
    styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {

    public products! :Product[];
    private subscription!: Subscription;

    // inject services (DI - Dependency Injection) using the CTOR
    constructor(
        private titleService: Title, 
        private productService:ProductsService,
        private router:Router
        ) { }

    ngOnInit(): void {
        this.titleService.setTitle("Products");
        // this.products = this.productService.getAllProducts();

        // 1. create a subscriber object to define what to do with results
        let subscriber: Partial<Observer<Product[]>> = {
            next:(arr)=>{
                this.products = arr;
            },

            complete: ()=>{
                this.subscription.unsubscribe();
                console.log("unsubscribed");
            } ,

            error:(e)=>{
                console.dir(e);
                alert(e.error.message);
                this.router.navigate(["/"]);
            }
        };
        
        // 2. get the observable - immediate
        let observable: Observable<Product[]> = this.productService.getAllProductsHttp();
        
        // 3. subscribe will start the asynchronius request of data
        this.subscription = observable.subscribe(subscriber);
        console.log("subscribed");

    }

    public activateService(){
        this.productService.x();
    }

}
